export interface OnTabViewWillEnter {
    tabViewWillEnter(): void;
}