import { ThumbnailDirective } from './thumbnail.directive';

describe('ThumbnailDirective', () => {
  it('should create an instance', () => {
    const directive = new ThumbnailDirective();
    expect(directive).toBeTruthy();
  });
});
