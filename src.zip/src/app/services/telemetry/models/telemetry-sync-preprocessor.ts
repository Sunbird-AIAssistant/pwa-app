export interface TelemetrySyncPreprocessor {
    process(input: any): any;
}