export interface TelemetrySyncStat {
    syncedEventCount: number;
    syncTime: number;
    syncedFileSize: number;
    error?: any;
}